import { GridAIDashboard } from "@/components/grid-ai-dashboard"

export default function Home() {
  return <GridAIDashboard />
}
